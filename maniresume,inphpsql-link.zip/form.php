<html>

<head>
<title>PHP</title>

</head>
<body>
<form action="var.php" method="POST" enctype="multipart/form-data">
	<input type="text" id="name" name="name">
	<input type="email" id="email" name="email">
		<input type="text" id="subject" name="subject">
	<input type="text" id="message" name="message">
	<input type="submit" id="submit" name="submit" value="submit">
</form>

</body>
</html>