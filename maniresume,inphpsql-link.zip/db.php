<?php

$conn = mysqli_connect('localhost','jointure_mani','manimani','jointure_manirojendar');
if (mysqli_connect_errno($conn)) {
	echo "Faided to connect".mysqli_connect_error();
	# code...
}


?>