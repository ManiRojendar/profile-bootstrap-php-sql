<?php
include("db.php");

$sql='SELECT *FROM students';
$retval=mysqli_query($conn, $sql);

if(mysqli_num_rows($retval)>0){
	while ($row=mysqli_fetch_assoc($retval)) {
		echo "<table border=\"1\">";
		echo "name:{$row['name']}";
		
	}
}
else
{
	echo  "0 results";
}


?>