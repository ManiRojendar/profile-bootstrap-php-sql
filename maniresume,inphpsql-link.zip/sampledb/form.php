<html>

<head>
<title>PHP</title>

</head>
<body>
<form action="var.php" method="post">
	<input type="text" id="name" name="name">
	<input type="email" id="email" name="email">
	<input type="submit" id="submit"name="submit" value="submit">
</form>

</body>
</html>