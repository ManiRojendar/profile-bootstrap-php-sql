<?php

$conn = mysqli_connect("localhost","root","","student");
if (mysqli_connect_errno($conn)) {
	echo "Faided to connect".mysqli_connect_error();
	# code...
}


?>