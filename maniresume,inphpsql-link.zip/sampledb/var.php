<?php
include("db.php");

if(isset($_POST['submit'])){
	$name = mysqli_real_escape_string($conn, $_POST['name']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$subject = mysqli_real_escape_string($conn, $_POST['subject']);
	$meassage = mysqli_real_escape_string($conn, $_POST['meassage']);






	$res = mysqli_query($conn, "INSERT INTO student (name, email, subject, meassage,) VALUES ('$name', '$email' '$subject' '$meassage' )");
	if($res){
		header("Location:contactus.html");
	}else{
		echo ("Error Description".mysqli_error($conn));
	}
     mysqli_close($conn);
}

?>