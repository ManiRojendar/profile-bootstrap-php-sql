<?php
include("db.php");

if(isset($_POST['submit'])){
	$name = mysqli_real_escape_string($conn, $_POST['name']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$subject = mysqli_real_escape_string($conn, $_POST['subject']);
	$message = mysqli_real_escape_string($conn, $_POST['message']);






	$res = mysqli_query($conn, "INSERT INTO students (name, email, subject, message) VALUES ('$name', '$email', '$subject', '$message' )");
	if($res){
		header("Location:submit.html");

	}else{
		echo ("Error Description".mysqli_error($conn));
	}
     mysqli_close($conn);
}

?>